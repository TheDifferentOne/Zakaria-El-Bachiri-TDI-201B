package com.example.pfemobile;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class ListRecipiesActivity extends AppCompatActivity {
    LinearLayout filterByCountry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_recipies);

        filterByCountry = findViewById(R.id.filterByCountry);

        filterByCountry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                filterByCountry.children
            }
        });
    }
}